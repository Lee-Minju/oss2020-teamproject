package com.example.shuttlebustime;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Weekday extends AppCompatActivity {


    private static final String TAG = "imagesearchexample";
    public static final int LOAD_SUCCESS = 101;

    private String SEARCH_URL = "https://develope.dev/";
    private ProgressDialog progressDialog = null;
    private SimpleAdapter adapter = null;
    private List<HashMap<String,String>> photoinfoList = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekday);

        ListView listviewPhtoList = (ListView)findViewById(R.id.listview_weekday_time_list);

        photoinfoList = new ArrayList<HashMap<String,String>>();

        String[] from = new String[]{"셔틀콕", "한대앞역", "예술인A", "창의인재원1", "창의인재원2"};
        int[] to = new int[] {R.id.textview_main_listviewdata1, R.id.textview_main_listviewdata2,
                R.id.textview_main_listviewdata3, R.id.textview_main_listviewdata4, R.id.textview_main_listviewdata5};
        adapter = new SimpleAdapter(this, photoinfoList, R.layout.listview_items, from, to);
        listviewPhtoList.setAdapter(adapter);

        progressDialog = new ProgressDialog(Weekday.this);
        progressDialog.setMessage("Please wait.....");
        progressDialog.show();
        getJSON("json");
    }

    private final MyHandler mHandler = new MyHandler(this);


    private static class MyHandler extends Handler {
        private final WeakReference<Weekday> weakReference;

        public MyHandler(Weekday mainactivity) {
            weakReference = new WeakReference<Weekday>(mainactivity);
        }

        @Override
        public void handleMessage(Message msg) {

            Weekday mainActivity = weakReference.get();

            if (mainActivity != null) {
                switch (msg.what) {

                    case LOAD_SUCCESS:
                        mainActivity.progressDialog.dismiss();
                        mainActivity.adapter.notifyDataSetChanged();
                        break;
                }
            }
        }
    }

    public void  getJSON(final String keyword) {

        if ( keyword == null) return;

        Thread thread = new Thread(new Runnable() {

            @RequiresApi(api = Build.VERSION_CODES.O)
            public void run() {

                String result;

                try {

                    Log.d(TAG, SEARCH_URL+keyword);
                    URL url = new URL(SEARCH_URL+keyword);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();


                    httpURLConnection.setReadTimeout(3000);
                    httpURLConnection.setConnectTimeout(3000);
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setUseCaches(false);
                    httpURLConnection.connect();


                    int responseStatusCode = httpURLConnection.getResponseCode();

                    InputStream inputStream;
                    if (responseStatusCode == HttpURLConnection.HTTP_OK) {

                        inputStream = httpURLConnection.getInputStream();
                    } else {
                        inputStream = httpURLConnection.getErrorStream();

                    }


                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                    StringBuilder sb = new StringBuilder();
                    String line;


                    while ((line = bufferedReader.readLine()) != null) {
                        sb.append(line);
                    }

                    bufferedReader.close();
                    httpURLConnection.disconnect();

                    result = sb.toString().trim();


                } catch (Exception e) {
                    result = e.toString();
                }



                if (jsonParser(result)){

                    Message message = mHandler.obtainMessage(LOAD_SUCCESS);
                    mHandler.sendMessage(message);
                }
            }

        });
        thread.start();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public boolean jsonParser(String jsonString){

        if (jsonString == null ) return false;

        try {
            JSONObject jsonobject = new JSONObject(jsonString);
            JSONArray TimeArray = jsonobject.getJSONArray("평일운행");

            photoinfoList.clear();
            int check = 0;
            HashMap<String, String> photoinfoMap = new HashMap<String, String>();
            String a = "";
            String b = "";
            String c = "";
            String d = "";
            String e = "";
            for (int i = 0; i < TimeArray.length(); i++) {
                JSONObject ListInfo = TimeArray.getJSONObject(i);

                String startingpoint = ListInfo.getString("startingpoint");
                String destination = ListInfo.getString("destination");
                String route = ListInfo.getString("route");
                String time = ListInfo.getString("time");

                int temp = Integer.parseInt(time);
                if(check < (temp/100) && i > 0){
                    photoinfoMap.put("셔틀콕", a);
                    photoinfoMap.put("한대앞역", b);
                    photoinfoMap.put("예술인A", c);
                    photoinfoMap.put("창의인재원1", d);
                    photoinfoMap.put("창의인재원2", e);
                    photoinfoList.add(photoinfoMap);
                    photoinfoMap = new HashMap<String, String>();
                    a = "";
                    b = "";
                    c = "";
                    d = "";
                    e = "";
                }
                if(destination.equals("셔틀콕")){
                    int P = Integer.parseInt(time);
                    int p = P%100;
                    P = P/100;
                    String H = String.valueOf(P) + "시" + String.valueOf(p) + "분";
                    a += H + "\n" + "(" + route + ")" + "\n";
                }
                else if(destination.equals("한대앞역")){
                    int P = Integer.parseInt(time);
                    int p = P%100;
                    P = P/100;
                    String H = String.valueOf(P) + "시" + String.valueOf(p) + "분";
                    b += H + "\n" + "(" + route + ")" + "\n";
                }
                else if(destination.equals("예술인APT")){
                    int P = Integer.parseInt(time);
                    int p = P%100;
                    P = P/100;
                    String H = String.valueOf(P) + "시" + String.valueOf(p) + "분";
                    c += H + "\n" + "(" + route + ")" + "\n";
                }
                else if(startingpoint.equals("한대앞역") && destination.equals("창의인재원")){
                    int P = Integer.parseInt(time);
                    int p = P%100;
                    P = P/100;
                    String H = String.valueOf(P) + "시" + String.valueOf(p) + "분";
                    d += H + "\n" + "(" + route + ")" + "\n";
                }
                else if(startingpoint.equals("예술인APT") && destination.equals("창의인재원")){
                    int P = Integer.parseInt(time);
                    int p = P%100;
                    P = P/100;
                    String H = String.valueOf(P) + "시" + String.valueOf(p) + "분";
                    e += H + "\n" + "(" + route + ")" + "\n";
                }
                else if(destination.equals("한대앞역-예술인APT")){
                    int P = Integer.parseInt(time);
                    int p = P%100;
                    P = P/100;
                    String H = String.valueOf(P) + "시" + String.valueOf(p) + "분";
                    b += H + "\n" + "(" + route + ")" + "\n";
                    c += H + "\n" + "(" + route + ")" + "\n";
                }


                check = temp/100;


            }
            photoinfoMap.put("셔틀콕", a);
            photoinfoMap.put("한대앞역", b);
            photoinfoMap.put("예술인A", c);
            photoinfoMap.put("창의인재원1", d);
            photoinfoMap.put("창의인재원2", e);
            photoinfoList.add(photoinfoMap);
            return true;
        } catch (JSONException e) {

            Log.d(TAG, e.toString() );
        }

        return false;
    }
}
